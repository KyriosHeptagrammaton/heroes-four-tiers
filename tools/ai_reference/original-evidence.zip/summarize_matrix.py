import json,collections,math,pathlib,sys
suffix=sys.argv[1] if len(sys.argv)>1 else ""
rows=[]
for line in open(pathlib.Path(__file__).with_name('matrix'+suffix+'.jsonl')):
 try: rows.append(json.loads(line))
 except json.JSONDecodeError: pass
F=['alpha','beta','gamma','delta']
out=[]
for case in dict.fromkeys((r['profile'],r['terrain']) for r in rows):
 rr=[r for r in rows if (r['profile'],r['terrain'])==case]
 if len(rr)!=1200: continue
 print('\nCASE',case,'N',len(rr),'draws',sum(r['over'] is not None and r['over']['winner'] is None for r in rr),'unfinished',sum(r['over'] is None for r in rr))
 scores={}
 for f in F:
  vals=[]
  for g in F:
   if f==g: continue
   sample=[r for r in rr if {r['a'],r['b']}=={f,g}]
   cluster=collections.defaultdict(list)
   for r in sample:
    score=.5 if r['over'] is None or r['over']['winner'] is None else float((r['over']['winner']==0)==(r['a']==f))
    cluster[r['seed']].append(score)
   values=[sum(v)/len(v) for v in cluster.values()]
   mean=sum(values)/len(values)
   se=math.sqrt(sum((v-mean)**2 for v in values)/(len(values)-1)/len(values))
   vals.append(mean)
   scores[f+'-'+g]={'score':mean,'ci95_approx_paired':[max(0,mean-1.984*se),min(1,mean+1.984*se)],'games':len(sample),'seed_pairs':len(values)}
  print(f,'overall',round(sum(vals)/len(vals)*100,2),'pairs',[(g,round(scores[f+'-'+g]['score']*100,1)) for g in F if g!=f])
 out.append({'profile':case[0],'terrain':case[1],'results':scores,'games':len(rr),'attacker_wins':sum(r['over'] is not None and r['over']['winner']==0 for r in rr),'defender_wins':sum(r['over'] is not None and r['over']['winner']==1 for r in rr),'draws':sum(r['over'] is not None and r['over']['winner'] is None for r in rr),'unfinished':sum(r['over'] is None for r in rr)})
pathlib.Path(__file__).with_name('matrix'+suffix+'_summary.json').write_text(json.dumps(out,indent=2))
