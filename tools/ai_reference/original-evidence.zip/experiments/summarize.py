"""Descriptive summaries of fixed audit scenarios; not equilibrium estimates."""
import collections,json,glob,random,statistics,os
out={}
for path in glob.glob(os.path.dirname(__file__)+'/*_vs_*.json'):
 d=json.load(open(path));rs=d['records']; cs=collections.Counter();groups=collections.defaultdict(list);seeds=collections.defaultdict(list)
 for r in rs:
  if r['over'] is None: cs['timeout']+=1;continue
  w=r['over']['winner']; lab='draw' if w is None else 'win' if w==r['challenger_side'] else 'loss';cs[lab]+=1
  score={'win':1.,'draw':.5,'loss':0.}[lab];groups[f"{r['faction']}:{r['shape']}"] .append(score);seeds[r['seed']].append(score)
 vals=[statistics.mean(s) for s in seeds.values()];rng=random.Random(7221);samples=sorted(statistics.mean(rng.choices(vals,k=len(vals))) for _ in range(10000))
 summary={'battles':len(rs),'counts':dict(cs),'score':sum(sum(v) for v in groups.values())/sum(len(v) for v in groups.values()),'scenario_scores':{k:{'battles':len(v),'score':statistics.mean(v)} for k,v in groups.items()},'distinct_seed_blocks':len(vals),'seed_cluster_bootstrap_95_exploratory':[samples[250],samples[9750]],'actions':d['actions'],'simulations':d['simulations'],'seconds':d['elapsed_seconds']}
 out[os.path.basename(path)]=summary
print(json.dumps(out,indent=2))
