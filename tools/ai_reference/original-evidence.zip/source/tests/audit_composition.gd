extends RefCounted
var failed := false
func st(k: String, n: int) -> Dictionary: return {"key":k,"count":n}
func run(_root) -> void:
	Battle._full=false
	var scenarios := [
		{"name":"skeletons_vs_berserkers", "key":"delta.1.1.m", "n":6, "splits":6,"extra":[],"enemy":[st("alpha.1.0.",12)]},
		{"name":"skeletons_vs_scatter", "key":"delta.1.1.m", "n":6,"splits":6,"extra":[],"enemy":[st("beta.4.0.",1),st("beta.1.0.",12)]},
		{"name":"incarnations_vs_trolls", "key":"beta.4.0.", "n":6,"splits":6,"extra":[],"enemy":[st("alpha.3.1.",24)]},
		{"name":"incarnations_vs_wights", "key":"beta.4.0.", "n":6,"splits":6,"extra":[],"enemy":[st("delta.4.0.",6)]},
		{"name":"angels_vs_archons", "key":"gamma.4.0.", "n":5,"splits":5,"extra":[st("gamma.1.0.",12)],"enemy":[st("beta.3.1.",20)]},
		{"name":"angels_vs_wights", "key":"gamma.4.0.", "n":5,"splits":5,"extra":[st("gamma.1.0.",12)],"enemy":[st("delta.4.0.",6)]}
	]
	var rows:=[]
	for sc in scenarios:
		for split in [false,true]:
			var army: Array=sc.extra.duplicate(true)
			var ns:int=sc.splits if split else 1
			for i in ns: army.append(st(sc.key,sc.n/ns))
			for side in 2:
				for seed in range(1001,1013):
					var sides := [{"stacks":army,"ai":true},{"stacks":sc.enemy,"ai":true}]
					if side==1: sides.reverse()
					var b:=Battle.new({"seed":seed,"sides":sides})
					var steps:=0
					b.check_end()
					while not b.over and steps<10000:
						CombatAI.step(b);steps+=1
					var score:=0.5 if b.over.winner==null else (1.0 if b.over.winner==side else 0.0)
					rows.append({"scenario":sc.name,"split":split,"side":side,"seed":seed,"score":score,"round":b.round_n,"reason":b.over.reason,"summary":b.summary()})
		print("FINISHED ",sc.name)
	var f:=FileAccess.open("/workspace/shared/heroes-four-tiers-audit/logs/composition.json",FileAccess.WRITE)
	f.store_string(JSON.stringify(rows));f.close()
	print("AUDIT composition games ",rows.size())
