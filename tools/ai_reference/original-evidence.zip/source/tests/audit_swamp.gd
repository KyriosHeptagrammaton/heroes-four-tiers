extends RefCounted
func run(_root) -> void:
	Battle._full = false
	var h = load("res://tests/audit_matrix.gd").new()
	var b := Battle.new({"seed":2026001,"terrain":"swamp","time":"dawn","weather":"clear","sides":[{"faction":"alpha","stacks":h.army("alpha","base"),"ai":true},{"faction":"beta","stacks":h.army("beta","base"),"ai":true}]})
	var n := 0
	while b.over == null and n < 20000:
		CombatAI.step(b); n += 1
	for l in b.log: print(l.t)
	print(JSON.stringify({"over":b.over,"round":b.round_n,"steps":n}))
