extends RefCounted
var failed := false
func make(a: Array, b: Array, seed: int = 1, probe: bool = false) -> Battle:
	return Battle.new({"seed": seed, "probe": probe, "sides": [{"stacks": a}, {"stacks": b}]})
func st(k: String, n: int) -> Dictionary:
	return {"key": k, "count": n}
func run(_root) -> void:
	Battle._full = false
	var b := make([st("alpha.1.0.", 6)], [st("alpha.1.0.", 6)], 1)
	var before := b.rng.get_state()
	b.expected_hit(b.stacks[0], b.stacks[1])
	print("AUDIT preview_rng ", JSON.stringify({"before": before, "after": b.rng.get_state()}))
	var changed := []
	for seed in range(1, 1001):
		var x := make([st("alpha.1.0.", 6)], [st("alpha.1.0.", 6)], seed)
		var y := make([st("alpha.1.0.", 6)], [st("alpha.1.0.", 6)], seed)
		y.hit_numbers(y.stacks[0], y.stacks[1], {"average": true})
		y.expected_hit(y.stacks[0], y.stacks[1])
		x.act("attack", 2); y.act("attack", 2)
		if x.stacks[1].count != y.stacks[1].count or x.stacks[1].phys != y.stacks[1].phys or x.stacks[1].mor != y.stacks[1].mor:
			changed.append(seed)
	print("AUDIT ui_preview_changes ", JSON.stringify({"seeds": 1000, "different_post_attack_states": changed.size(), "first_seeds": changed.slice(0, 10)}))
	b = make([st("gamma.1.0.", 6)], [st("gamma.1.0.", 6)])
	print("AUDIT tie_first ", JSON.stringify(b.current()))
	while not b.over:
		CombatAI.step(b)
	print("AUDIT slow_mirror ", JSON.stringify({"round": b.round_n, "over": b.over, "log": b.log}))
	for splits in [1, 6]:
		var arr := []
		for i in splits: arr.append(st("delta.1.1.m", 6 / splits))
		b = make(arr, [st("alpha.1.0.", 20)], 1, true)
		var res := b.deal_damage(b.stacks[-1], 20, 0)
		var gained := 0
		for s in b.stacks_of(0): gained += s.gained
		print("AUDIT necro_split ", JSON.stringify({"splits": splits, "initial_total": 6, "enemy_killed": res.killed, "gained": gained}))
	for splits in [1, 6]:
		var arr := []
		for i in splits: arr.append(st("beta.4.0.", 6 / splits))
		b = make(arr, [st("alpha.1.0.", 10)])
		print("AUDIT titan_split ", JSON.stringify({"splits": splits, "initial_titans": 6, "enemy_deserters_before_turn": b.stacks[-1].deserters}))
	b = make([st("delta.4.0.", 1)], [st("alpha.1.1.r", 6)])
	print("AUDIT enemy_rally ", JSON.stringify({"attack_error": b.check_attack(b.stacks[0], b.stacks[1]), "rally_error": b.check_rally(b.stacks[0], b.stacks[1]), "rally_morale_damage": 2*b.stacks[0].morale_val, "builtin_choice": CombatAI.decide(b,b.stacks[0])}))
	var c := b.clone_view()
	print("AUDIT clone_rng ", JSON.stringify({"original": b.rng.get_state(), "clone": c.rng.get_state()}))
	for n in range(1, 31):
		b = make([st("alpha.4.0.", n)], [st("beta.4.1.m", 3)], 1, true)
		var estimate := b.expected_hit(b.stacks[0], b.stacks[1])
		var hit := b.hit_numbers(b.stacks[0], b.stacks[1], {"average": true})
		var result := b.deal_damage(b.stacks[1],hit.phys,hit.mor)
		if estimate.removed != result.killed+result.deserted:
			print("AUDIT laststand_preview ",JSON.stringify({"attacker_count":n,"target_count":3,"preview_removed":estimate.removed,"actual_removed_average":result.killed+result.deserted,"input_phys":hit.phys,"input_mor":hit.mor}))
			break
	for splits in [1, 5]:
		var arr := [st("gamma.1.0.", 6)]
		for i in splits: arr.append(st("gamma.4.0.", 5 / splits))
		b = make(arr,[st("alpha.1.0.",20)],1,true)
		print("AUDIT aura_split ",JSON.stringify({"splits":splits,"total_angels":5,"pikeman_morale":b.stacks[0].morale_val}))
