extends RefCounted
func army(f: String, profile: String) -> Array:
	var out := []
	for t in range(1, 5):
		if profile.begins_with("solo") and t != int(profile.substr(4,1)): continue
		if profile == "no4" and t == 4: continue
		var up := 0
		var mod := ""
		if profile == "melee1" or profile.ends_with("up"): up = 1
		if profile == "ranged1":
			up = 1
			mod = "r" if t < 4 else ""
		if profile == "magi":
			up = 1; mod = "m"
		if profile == "native2":
			up = 2 if t < 4 else 1
			mod = str(D.SECOND_UPGRADE[f][str(t)]) if t < 4 else ""
		var n: int = [0,24,12,8,4][t]
		if profile == "small": n = [0,6,3,2,1][t]
		if profile == "large": n *= 2
		if profile.begins_with("solo"): n = [0,80,30,12,3][t]
		if profile == "growth" and f == "gamma" and t == 3: n *= 2
		out.append({"key": Units.key(f,t,up,mod), "count":n})
	return out
func run(_root) -> void:
	Battle._full = false
	var fs := ["alpha","beta","gamma","delta"]
	var cases := []
	for p in ["small","large","no4","solo1","solo2","solo3","solo4","solo1up","solo2up","solo3up","solo4up"]:
		cases.append([p,"field"])
	var out := FileAccess.open("/workspace/shared/heroes-four-tiers-audit/matrix_scales.jsonl",FileAccess.WRITE)
	var count := 0
	for c in cases:
		for i in range(4):
			for j in range(4):
				if i == j: continue
				for seed_i in range(100):
					var seed_n := 2026001 + seed_i * 7919
					var b := Battle.new({"seed":seed_n,"terrain":c[1],"time":"dawn","weather":"clear","sides":[{"faction":fs[i],"stacks":army(fs[i],c[0]),"ai":true},{"faction":fs[j],"stacks":army(fs[j],c[0]),"ai":true}]})
					var n := 0
					while b.over == null and n < 20000:
						CombatAI.step(b); n += 1
					var remain := [0,0]
					for s in b.stacks: remain[s.side] += s.count
					out.store_line(JSON.stringify({"profile":c[0],"terrain":c[1],"a":fs[i],"b":fs[j],"seed":seed_n,"over":b.over,"rounds":b.round_n,"steps":n,"remaining":remain}))
					count += 1
		out.flush()
		print("completed ",c," cumulative ",count)
	out.close()
