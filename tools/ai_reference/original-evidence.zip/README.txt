Heroes of Four Seasons: combat test evidence

Test target: release commit 26d4cdc0436c740cae6a2524bdfd057789f247a7
https://github.com/KyriosHeptagrammaton/heroes-four-tiers/tree/26d4cdc0436c740cae6a2524bdfd057789f247a7
Runtime: official Godot 4.3 stable, Linux, headless native GDScript rules.
Windows executable and interactive UI were not validated.
No production game rules were changed.

Contents
- source/tests/audit_*.gd: local test harnesses
- matrix*.jsonl: individual baseline battle records
- matrix*_summary.json: summaries; scores count draws as half a win
- experiments/: tactical-policy results and summarizer (pilot and completed runs are identified separately)
- logs/: focused mechanics reproductions and summaries
- SHA256SUMS.json: hashes for every evidence file

Reproduction
1. Download the pinned source commit above and the official Godot 4.3 runtime.
2. Copy the audit GDScript files into its tests directory.
3. The scripts preserve their original output paths. Replace /workspace/shared/heroes-four-tiers-audit/ with your chosen audit-output directory before running them. Create the experiments and logs subdirectories.
4. Use writable HOME/XDG runtime directories if your environment restricts the default locations.
5. Run: godot --headless --path <game-source> -- --test=audit_matrix
   Other entry points: audit_scales, audit_heroes, audit_fidelity, audit_composition, audit_swamp, audit_strong.
6. audit_strong reads AUDIT_POLICY, AUDIT_OPPONENT, AUDIT_SEEDS, AUDIT_HORIZON and AUDIT_SAMPLES. See the harness and each result's metadata for the exact settings, including held-out seed selections.

Interpretation
The large matrices use the shipped AI and selected matched rosters. The tactical-policy experiments isolate random-number consumption during decision previews. These are different experimental regimes and should not be directly pooled into one faction ranking. Neither proves optimal play or full campaign balance. Composition test armies are controlled for layout changes, not equal-budget faction comparisons. Read the accompanying report for limitations and conclusions.
